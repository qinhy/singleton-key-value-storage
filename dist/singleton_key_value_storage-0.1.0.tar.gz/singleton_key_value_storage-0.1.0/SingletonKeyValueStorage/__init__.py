# from https://github.com/qinhy/singleton-key-value-storage.git
from .Storages import SingletonKeyValueStorage,Tests
from .BasicModel import BasicModel,Model4Basic,Controller4Basic